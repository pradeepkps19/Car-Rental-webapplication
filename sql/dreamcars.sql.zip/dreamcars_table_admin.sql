
-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Creation: Sep 29, 2019 at 07:30 AM
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `uname`, `pass`) VALUES
(1, 'pradeep', 'pp19ss20'),
(2, 'admin', 'admin'),
(3, 'admin', 'admin');
