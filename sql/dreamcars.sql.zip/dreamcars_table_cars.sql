
-- --------------------------------------------------------

--
-- Table structure for table `cars`
--
-- Creation: Sep 28, 2019 at 11:27 PM
--

CREATE TABLE `cars` (
  `car_id` int(10) NOT NULL,
  `car_name` varchar(20) NOT NULL,
  `image` blob NOT NULL,
  `car_type` varchar(10) NOT NULL,
  `hire_cost` int(8) NOT NULL,
  `capacity` int(5) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_id`, `car_name`, `image`, `car_type`, `hire_cost`, `capacity`, `status`) VALUES
(2, 'Scorpio/S5', 0x6262622e6a7067, 'Mahindra', 6449, 8, 'Available'),
(3, 'Xylo/D2', 0x6363632e706e67, 'Mahindra', 6999, 8, 'Available'),
(4, 'Duster/ RXZ', 0x6475737465722e706e67, 'Renault', 6899, 7, 'Available'),
(5, 'Logan/ 1.6 GLS', 0x6c6f67616e2e706e67, 'Renault', 3999, 5, 'Available'),
(6, 'Bolero/ZLX', 0x6161612e6a7067, 'Mahindra', 4999, 7, 'Available'),
(7, 'Kwid/RXL 0.8', 0x6b7769642e706e67, 'Renault', 4499, 5, 'Available'),
(8, 'Fortuner/ 2.4L 2X4 M', 0x666f7274756e65722e706e67, 'Toyota', 6799, 7, 'Available'),
(9, 'Innova Crysta', 0x696e6e6f76612e706e67, 'Toyota', 4799, 8, 'Available'),
(12, 'Creta / 1.4L VGT CRD', 0x63726574612e706e67, 'Hyundai', 6899, 5, 'Available'),
(13, 'i10 / D lite1086 cc', 0x6931302e706e67, 'Hyundai', 3999, 5, 'Available');
