
-- --------------------------------------------------------

--
-- Table structure for table `client`
--
-- Creation: Sep 29, 2019 at 07:37 AM
--

CREATE TABLE `client` (
  `fname` varchar(30) NOT NULL,
  `client_id` int(11) NOT NULL,
  `id_no` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `location` varchar(20) NOT NULL,
  `car_id` int(10) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `mpesa` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`fname`, `client_id`, `id_no`, `gender`, `email`, `phone`, `location`, `car_id`, `status`, `mpesa`) VALUES
('Pradeep', 1, 1920, 'Male', 'pradeepkps19@gmail.com', '7845104680', 'Coimbatore', 0, 'Available', ''),
('Ramachandran', 2, 1001, 'Male', 'manirama218@gmail.com', '9875643210', 'Madurai', 5, 'Approved', ''),
('Pranav', 3, 10023, 'Male', 'pranavkm@gmail.com', '8876512908', 'Madurai', 13, 'Approved', '');
