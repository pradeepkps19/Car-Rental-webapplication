
-- --------------------------------------------------------

--
-- Table structure for table `hire`
--
-- Creation: Sep 29, 2019 at 07:29 AM
--

CREATE TABLE `hire` (
  `hire_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
