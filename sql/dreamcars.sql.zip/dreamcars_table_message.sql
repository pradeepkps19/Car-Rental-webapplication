
-- --------------------------------------------------------

--
-- Table structure for table `message`
--
-- Creation: Sep 29, 2019 at 07:27 AM
--

CREATE TABLE `message` (
  `message` text NOT NULL,
  `msg_id` int(11) NOT NULL,
  `client_id` varchar(10) NOT NULL,
  `time` datetime NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message`, `msg_id`, `client_id`, `time`, `status`) VALUES
('Hello admin!\r\n', 1, 'pradeepkps', '2019-10-06 16:09:06', 'Unread');
